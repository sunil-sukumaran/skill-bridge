import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Heart, 
  Users, 
  Globe, 
  Lightbulb,
  Target,
  Award,
  BookOpen,
  Smartphone,
  MapPin
} from 'lucide-react';
import Footer from "@/components/Footer";
import Navigation from "@/components/Navigation";

const About = () => {
  const values = [
    {
      icon: Heart,
      title: "Empathy-Driven",
      description: "We understand the unique challenges faced by rural communities and design solutions with deep empathy."
    },
    {
      icon: Users,
      title: "Community-First",
      description: "Building bridges between learners, mentors, and local employers to create sustainable ecosystems."
    },
    {
      icon: Globe,
      title: "Culturally Aware",
      description: "Respecting local languages, customs, and learning preferences while delivering global opportunities."
    },
    {
      icon: Lightbulb,
      title: "Innovation",
      description: "Leveraging cutting-edge AI and blockchain technology to solve real-world accessibility problems."
    }
  ];

  const stats = [
    { number: "10M+", label: "Rural Youth Target", icon: Users },
    { number: "28", label: "States Covered", icon: MapPin },
    { number: "4", label: "Native Languages", icon: Globe },
    { number: "50+", label: "Skill Courses", icon: BookOpen }
  ];

  const teamHighlights = [
    {
      role: "Rural Outreach",
      description: "Team members from rural backgrounds who understand ground realities",
      icon: Heart
    },
    {
      role: "AI Specialists", 
      description: "Experts in Gemma 3, Whisper AI, and multilingual NLP technologies",
      icon: Lightbulb
    },
    {
      role: "Blockchain Developers",
      description: "Building verifiable credentials on Polygon for trusted certifications",
      icon: Award
    },
    {
      role: "Education Experts",
      description: "Curriculum designers with experience in rural education challenges",
      icon: Target
    }
  ];

  return (
    <>
      <Navigation />
      <section id="about" className="bg-gray-50 text-black py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                About <span className="text-blue-400">SkillBridge</span>
              </h2>
              <p className="text-xl text-gray-700 max-w-4xl mx-auto leading-relaxed">
                We're on a mission to democratize digital skills education for India's underserved communities. 
                SkillBridge isn't just a platform - it's a movement to unlock human potential in every corner of our nation.
              </p>
            </div>

            {/* Mission Statement */}
            <div className="bg-white rounded-2xl p-8 mb-16 shadow-sm">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h3>
                <blockquote className="text-2xl italic text-gray-700 font-medium">
                  "To bridge the digital divide by making quality skills education accessible, 
                  affordable, and culturally relevant for rural India."
                </blockquote>
              </div>
              
              <div className="grid md:grid-cols-2 gap-8 mt-8">
                <div className="text-center">
                  <Smartphone className="h-12 w-12 text-blue-500 mx-auto mb-4" />
                  <h4 className="font-semibold text-gray-900 mb-2">Mobile-First</h4>
                  <p className="text-gray-600 text-sm">Designed for the smartphones that rural India already uses</p>
                </div>
                <div className="text-center">
                  <Globe className="h-12 w-12 text-purple-500 mx-auto mb-4" />
                  <h4 className="font-semibold text-gray-900 mb-2">Local Language</h4>
                  <p className="text-gray-600 text-sm">Education in mother tongues for better comprehension</p>
                </div>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
              {stats.map((stat, index) => (
                <Card key={index} className="bg-white text-center shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <stat.icon className="h-8 w-8 text-blue-500 mx-auto mb-3" />
                    <div className="text-3xl font-bold text-gray-900 mb-1">{stat.number}</div>
                    <div className="text-sm text-gray-600">{stat.label}</div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Values */}
            <div className="mb-16">
              <h3 className="text-3xl font-bold text-center mb-12 text-gray-900">Our Values</h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {values.map((value, index) => (
                  <Card key={index} className="bg-white hover:shadow-lg transition-shadow">
                    <CardContent className="p-6 text-center">
                      <value.icon className="h-10 w-10 text-blue-500 mx-auto mb-4" />
                      <h4 className="font-bold text-gray-900 mb-2">{value.title}</h4>
                      <p className="text-gray-600 text-sm">{value.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Team */}
            <div className="bg-white rounded-2xl p-8 mb-16">
              <h3 className="text-3xl font-bold text-center mb-8 text-gray-900">Our Team</h3>
              <p className="text-center text-gray-700 mb-8 max-w-3xl mx-auto">
                A diverse team of technologists, educators, and rural development experts united by 
                a common goal: making quality education accessible to all.
              </p>
              
              <div className="grid md:grid-cols-2 gap-6">
                {teamHighlights.map((highlight, index) => (
                  <div key={index} className="flex items-start space-x-4 p-4 rounded-lg bg-gray-50">
                    <highlight.icon className="h-6 w-6 text-blue-500 flex-shrink-0 mt-1" />
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">{highlight.role}</h4>
                      <p className="text-gray-600 text-sm">{highlight.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Call to Action */}
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl p-8 text-white text-center">
              <h3 className="text-2xl font-bold mb-4">Join Our Mission</h3>
              <p className="text-lg mb-6 opacity-90 max-w-2xl mx-auto">
                Whether you're a learner, educator, employer, or supporter - there's a place for you 
                in the SkillBridge community. Together, we can transform rural India's digital future.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button className="bg-white text-blue-600 hover:bg-gray-100">
                  Become a Mentor
                </Button>
                <Button variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
                  Partner with Us
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default About;