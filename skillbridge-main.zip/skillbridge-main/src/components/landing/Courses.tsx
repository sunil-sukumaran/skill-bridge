import React, { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Code, 
  Smartphone, 
  BarChart3, 
  Camera, 
  Paintbrush,
  Wrench,
  CheckCircle,
  Clock,
  Users,
  Award,
  QrCode,
  Shield,
  ArrowRight,
  Play,
  BookOpen,
  Target,
  Trophy,
  Star
} from 'lucide-react';
import Footer from "@/components/Footer";
import Navigation from "@/components/Navigation";

const Courses = () => {
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null);

  const courses = [
    {
      id: 'web-dev',
      title: 'Web Development',
      description: 'Learn HTML, CSS, JavaScript, and React to build modern websites',
      icon: Code,
      duration: '12 weeks',
      level: 'Beginner to Intermediate',
      students: '2,500+',
      rating: 4.8,
      color: 'blue',
      skills: ['HTML/CSS', 'JavaScript', 'React', 'Node.js'],
      milestones: [
        { title: 'HTML & CSS Basics', duration: '2 weeks', completed: false },
        { title: 'JavaScript Fundamentals', duration: '3 weeks', completed: false },
        { title: 'React Development', duration: '4 weeks', completed: false },
        { title: 'Backend with Node.js', duration: '2 weeks', completed: false },
        { title: 'Full Stack Project', duration: '1 week', completed: false }
      ],
      jobOpportunities: ['Frontend Developer', 'Full Stack Developer', 'Web Designer'],
      avgSalary: '₹3-8 lakhs/year'
    },
    {
      id: 'mobile-dev',
      title: 'Mobile App Development',
      description: 'Create Android and iOS apps using React Native and Flutter',
      icon: Smartphone,
      duration: '10 weeks',
      level: 'Intermediate',
      students: '1,800+',
      rating: 4.7,
      color: 'green',
      skills: ['React Native', 'Flutter', 'Dart', 'Mobile UI/UX'],
      milestones: [
        { title: 'Mobile Development Basics', duration: '2 weeks', completed: false },
        { title: 'React Native Fundamentals', duration: '3 weeks', completed: false },
        { title: 'Flutter Development', duration: '3 weeks', completed: false },
        { title: 'App Deployment', duration: '1 week', completed: false },
        { title: 'Portfolio App Project', duration: '1 week', completed: false }
      ],
      jobOpportunities: ['Mobile App Developer', 'Cross-platform Developer', 'UI/UX Designer'],
      avgSalary: '₹4-10 lakhs/year'
    },
    {
      id: 'digital-marketing',
      title: 'Digital Marketing',
      description: 'Master social media, SEO, content marketing, and analytics',
      icon: BarChart3,
      duration: '8 weeks',
      level: 'Beginner',
      students: '3,200+',
      rating: 4.9,
      color: 'purple',
      skills: ['Social Media Marketing', 'SEO', 'Google Ads', 'Analytics'],
      milestones: [
        { title: 'Digital Marketing Fundamentals', duration: '1 week', completed: false },
        { title: 'Social Media Strategy', duration: '2 weeks', completed: false },
        { title: 'SEO & Content Marketing', duration: '2 weeks', completed: false },
        { title: 'Paid Advertising', duration: '2 weeks', completed: false },
        { title: 'Campaign Project', duration: '1 week', completed: false }
      ],
      jobOpportunities: ['Digital Marketing Specialist', 'Social Media Manager', 'SEO Analyst'],
      avgSalary: '₹2-6 lakhs/year'
    },
    {
      id: 'graphic-design',
      title: 'Graphic Design',
      description: 'Learn design principles, Adobe tools, and create stunning visuals',
      icon: Paintbrush,
      duration: '6 weeks',
      level: 'Beginner',
      students: '2,100+',
      rating: 4.6,
      color: 'pink',
      skills: ['Adobe Photoshop', 'Illustrator', 'Design Principles', 'Branding'],
      milestones: [
        { title: 'Design Fundamentals', duration: '1 week', completed: false },
        { title: 'Adobe Photoshop Mastery', duration: '2 weeks', completed: false },
        { title: 'Illustrator & Vector Design', duration: '2 weeks', completed: false },
        { title: 'Portfolio Development', duration: '1 week', completed: false }
      ],
      jobOpportunities: ['Graphic Designer', 'Brand Designer', 'Visual Content Creator'],
      avgSalary: '₹2-5 lakhs/year'
    },
    {
      id: 'photography',
      title: 'Photography & Video',
      description: 'Master photography techniques and video editing for content creation',
      icon: Camera,
      duration: '6 weeks',
      level: 'Beginner',
      students: '1,500+',
      rating: 4.5,
      color: 'yellow',
      skills: ['Photography Basics', 'Video Editing', 'Content Creation', 'Social Media'],
      milestones: [
        { title: 'Photography Fundamentals', duration: '2 weeks', completed: false },
        { title: 'Video Recording & Editing', duration: '2 weeks', completed: false },
        { title: 'Content Strategy', duration: '1 week', completed: false },
        { title: 'Portfolio Creation', duration: '1 week', completed: false }
      ],
      jobOpportunities: ['Photographer', 'Video Editor', 'Content Creator'],
      avgSalary: '₹1.5-4 lakhs/year'
    },
    {
      id: 'data-entry',
      title: 'Data Entry & Admin',
      description: 'Learn efficient data management and administrative skills',
      icon: Wrench,
      duration: '4 weeks',
      level: 'Beginner',
      students: '4,000+',
      rating: 4.4,
      color: 'indigo',
      skills: ['Microsoft Office', 'Data Management', 'Admin Skills', 'Time Management'],
      milestones: [
        { title: 'Office Suite Mastery', duration: '2 weeks', completed: false },
        { title: 'Data Management', duration: '1 week', completed: false },
        { title: 'Professional Skills', duration: '1 week', completed: false }
      ],
      jobOpportunities: ['Data Entry Operator', 'Virtual Assistant', 'Admin Assistant'],
      avgSalary: '₹1-3 lakhs/year'
    }
  ];

  const getColorClasses = (color: string) => {
    const colorMap: Record<string, any> = {
      blue: { bg: 'from-blue-50 to-cyan-50', border: 'border-blue-200', text: 'text-blue-800', accent: 'bg-blue-500' },
      green: { bg: 'from-green-50 to-emerald-50', border: 'border-green-200', text: 'text-green-800', accent: 'bg-green-500' },
      purple: { bg: 'from-purple-50 to-indigo-50', border: 'border-purple-200', text: 'text-purple-800', accent: 'bg-purple-500' },
      pink: { bg: 'from-pink-50 to-rose-50', border: 'border-pink-200', text: 'text-pink-800', accent: 'bg-pink-500' },
      yellow: { bg: 'from-yellow-50 to-amber-50', border: 'border-yellow-200', text: 'text-yellow-800', accent: 'bg-yellow-500' },
      indigo: { bg: 'from-indigo-50 to-blue-50', border: 'border-indigo-200', text: 'text-indigo-800', accent: 'bg-indigo-500' }
    };
    return colorMap[color] || colorMap.blue;
  };

  const CourseModal = ({ course }: { course: any }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          {/* Header */}
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center space-x-4">
              <div className={`p-3 rounded-full ${getColorClasses(course.color).accent} text-white`}>
                <course.icon className="h-8 w-8" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">{course.title}</h2>
                <p className="text-gray-600">{course.description}</p>
              </div>
            </div>
            <button
              onClick={() => setSelectedCourse(null)}
              className="text-gray-400 hover:text-gray-600 text-2xl"
            >
              ×
            </button>
          </div>

          {/* Course Info */}
          <div className="grid md:grid-cols-4 gap-4 mb-8">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <Clock className="h-6 w-6 text-gray-600 mx-auto mb-2" />
              <div className="font-semibold">{course.duration}</div>
              <div className="text-sm text-gray-600">Duration</div>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <Users className="h-6 w-6 text-gray-600 mx-auto mb-2" />
              <div className="font-semibold">{course.students}</div>
              <div className="text-sm text-gray-600">Students</div>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <Star className="h-6 w-6 text-yellow-500 mx-auto mb-2" />
              <div className="font-semibold">{course.rating}/5</div>
              <div className="text-sm text-gray-600">Rating</div>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <Target className="h-6 w-6 text-gray-600 mx-auto mb-2" />
              <div className="font-semibold">{course.level}</div>
              <div className="text-sm text-gray-600">Level</div>
            </div>
          </div>

          {/* Learning Path */}
          <div className="mb-8">
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <BookOpen className="h-5 w-5 mr-2" />
              Learning Milestones
            </h3>
            <div className="space-y-3">
              {course.milestones.map((milestone: any, index: number) => (
                <div key={index} className="flex items-center space-x-4 p-4 border rounded-lg">
                  <div className="flex-shrink-0">
                    <CheckCircle className="h-6 w-6 text-gray-300" />
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold text-gray-900">{milestone.title}</div>
                    <div className="text-sm text-gray-600">{milestone.duration}</div>
                  </div>
                  <div className="text-sm text-gray-500">
                    Milestone {index + 1}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Skills & Certification */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div>
              <h4 className="font-bold mb-3">Skills You'll Learn</h4>
              <div className="flex flex-wrap gap-2">
                {course.skills.map((skill: string, index: number) => (
                  <span key={index} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
            <div>
              <h4 className="font-bold mb-3">Job Opportunities</h4>
              <div className="space-y-2">
                {course.jobOpportunities.map((job: string, index: number) => (
                  <div key={index} className="flex items-center space-x-2">
                    <ArrowRight className="h-4 w-4 text-green-500" />
                    <span className="text-gray-700">{job}</span>
                  </div>
                ))}
              </div>
              <div className="mt-2 text-sm text-gray-600">
                Average Salary: <span className="font-semibold">{course.avgSalary}</span>
              </div>
            </div>
          </div>

          {/* Certification Process */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6 mb-6">
            <h4 className="font-bold mb-4 flex items-center">
              <Award className="h-5 w-5 mr-2 text-blue-600" />
              Blockchain Certification Process
            </h4>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="bg-blue-500 text-white rounded-full w-8 h-8 flex items-center justify-center mx-auto mb-2 text-sm font-bold">1</div>
                <div className="font-semibold text-sm">Complete Milestones</div>
                <div className="text-xs text-gray-600">Finish all learning modules</div>
              </div>
              <div className="text-center">
                <div className="bg-purple-500 text-white rounded-full w-8 h-8 flex items-center justify-center mx-auto mb-2 text-sm font-bold">2</div>
                <div className="font-semibold text-sm">Take Final Test</div>
                <div className="text-xs text-gray-600">Score 70% to pass</div>
              </div>
              <div className="text-center">
                <div className="bg-green-500 text-white rounded-full w-8 h-8 flex items-center justify-center mx-auto mb-2 text-sm font-bold">3</div>
                <div className="font-semibold text-sm">Get Certificate</div>
                <div className="text-xs text-gray-600">Blockchain verified with QR</div>
              </div>
            </div>
          </div>

          {/* Certificate Features */}
          <div className="bg-white border-2 border-gray-200 rounded-lg p-4 mb-6">
            <h4 className="font-bold mb-3 flex items-center">
              <Shield className="h-5 w-5 mr-2 text-green-600" />
              Your Certificate Will Include
            </h4>
            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div className="flex items-center space-x-2">
                <QrCode className="h-4 w-4 text-blue-500" />
                <span>QR Code for instant verification</span>
              </div>
              <div className="flex items-center space-x-2">
                <Shield className="h-4 w-4 text-green-500" />
                <span>Stored on Polygon blockchain</span>
              </div>
              <div className="flex items-center space-x-2">
                <Award className="h-4 w-4 text-yellow-500" />
                <span>Your name and course details</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-purple-500" />
                <span>Tamper-proof and permanent</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button className="flex-1 bg-blue-500 hover:bg-blue-600 text-white">
              <Play className="h-4 w-4 mr-2" />
              Start Learning
            </Button>
            <Button variant="outline" className="flex-1">
              <BookOpen className="h-4 w-4 mr-2" />
              View Curriculum
            </Button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      <Navigation />
      <section id="courses" className="bg-white text-black py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                Courses That Lead to <span className="text-blue-400">Real Jobs</span>
              </h2>
              <p className="text-xl text-gray-700 max-w-3xl mx-auto">
                Each course is designed with input from employers, includes hands-on projects, 
                and leads to blockchain-verified certificates that prove your skills.
              </p>
            </div>

            {/* Course Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
              {courses.map((course) => {
                const colors = getColorClasses(course.color);
                return (
                  <Card 
                    key={course.id}
                    className={`bg-gradient-to-br ${colors.bg} border-2 ${colors.border} hover:shadow-lg transition-all duration-300 hover:scale-105 cursor-pointer`}
                    onClick={() => setSelectedCourse(course.id)}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <course.icon className={`h-8 w-8 ${colors.text}`} />
                        <div className="flex items-center space-x-1">
                          <Star className="h-4 w-4 text-yellow-500 fill-current" />
                          <span className="text-sm font-medium">{course.rating}</span>
                        </div>
                      </div>
                      
                      <h3 className={`text-xl font-bold mb-2 ${colors.text}`}>{course.title}</h3>
                      <p className="text-gray-700 text-sm mb-4 line-clamp-2">{course.description}</p>
                      
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-600">Duration:</span>
                          <span className="font-medium">{course.duration}</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-600">Students:</span>
                          <span className="font-medium">{course.students}</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-600">Level:</span>
                          <span className="font-medium">{course.level}</span>
                        </div>
                      </div>

                      <Button className={`w-full ${colors.accent} hover:opacity-90 text-white`}>
                        Learn More
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Learning Process */}
            <div className="bg-gray-50 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-center mb-8">How Learning Works</h3>
              <div className="grid md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="bg-blue-500 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <Play className="h-8 w-8" />
                  </div>
                  <h4 className="font-bold mb-2">Start Course</h4>
                  <p className="text-gray-600 text-sm">Begin with interactive lessons in your language</p>
                </div>
                <div className="text-center">
                  <div className="bg-green-500 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <Target className="h-8 w-8" />
                  </div>
                  <h4 className="font-bold mb-2">Complete Milestones</h4>
                  <p className="text-gray-600 text-sm">Progress through structured learning modules</p>
                </div>
                <div className="text-center">
                  <div className="bg-purple-500 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <BookOpen className="h-8 w-8" />
                  </div>
                  <h4 className="font-bold mb-2">Take Assessment</h4>
                  <p className="text-gray-600 text-sm">Prove your skills with comprehensive tests</p>
                </div>
                <div className="text-center">
                  <div className="bg-yellow-500 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <Trophy className="h-8 w-8" />
                  </div>
                  <h4 className="font-bold mb-2">Earn Certificate</h4>
                  <p className="text-gray-600 text-sm">Get blockchain-verified credentials</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Course Modal */}
        {selectedCourse && (
          <CourseModal course={courses.find(c => c.id === selectedCourse)} />
        )}
      </section>
      <Footer />
    </>
  );
};

export default Courses;