import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { 
  Smartphone, 
  Globe, 
  Brain, 
  Award, 
  Users, 
  Download,
  Wifi,
  Languages,
  Shield,
  Zap,
  Target,
  BookOpen
} from 'lucide-react';
import Footer from "@/components/Footer";
import Navigation from "@/components/Navigation";

const Features = () => {
  const mainFeatures = [
    {
      icon: Globe,
      title: "Whisper AI-Powered Multilingual",
      description: "Learn in Hindi, Tamil, Telugu, or Bengali with AI-powered voice recognition and native language support.",
      color: "green"
    },
    {
      icon: Brain,
      title: "Personalized AI (Gemma 3)",
      description: "Adaptive content powered by Gemma 3 AI that adjusts to your learning pace, device capabilities, and bandwidth.",
      color: "purple"
    },
    {
      icon: Award,
      title: "Blockchain Certificates",
      description: "Earn verified credentials stored on Polygon blockchain with QR codes for instant verification by employers.",
      color: "yellow"
    },
    {
      icon: Users,
      title: "Gamified Learning",
      description: "Stay motivated with XP points, achievement badges, leaderboards, and milestone rewards.",
      color: "red"
    },
    {
      icon: Target,
      title: "AI Job Matching",
      description: "Connect with local employers and mentors based on your completed skills and certifications.",
      color: "indigo"
    }
  ];

  const additionalFeatures = [
    {
      icon: Languages,
      title: "Cultural Context",
      description: "Examples and case studies relevant to Indian rural communities"
    },
    {
      icon: Shield,
      title: "Secure & Private",
      description: "Your learning data is protected with industry-standard encryption"
    },
    {
      icon: Zap,
      title: "Quick Start",
      description: "Begin learning in under 5 minutes with our streamlined onboarding"
    },
    {
      icon: BookOpen,
      title: "Rich Content",
      description: "Interactive videos, quizzes, and hands-on projects for better retention"
    }
  ];

  const getColorClasses = (color: string) => {
    const colorMap: Record<string, string> = {
      green: "from-green-50 to-emerald-50 border-green-200 text-green-800",
      purple: "from-purple-50 to-indigo-50 border-purple-200 text-purple-800",
      yellow: "from-yellow-50 to-amber-50 border-yellow-200 text-yellow-800",
      red: "from-red-50 to-pink-50 border-red-200 text-red-800",
      indigo: "from-indigo-50 to-blue-50 border-indigo-200 text-indigo-800"
    };
    return colorMap[color] || colorMap.green;
  };

  return (
    <>
      <Navigation />
      <section id="features" className="bg-white text-black py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                Features Built for <span className="text-blue-400">Rural India</span>
              </h2>
              <p className="text-xl text-gray-700 max-w-3xl mx-auto">
                Every feature is designed with rural realities in mind - ensuring quality education reaches everyone.
              </p>
            </div>

            {/* Main Features Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
              {mainFeatures.map((feature, index) => (
                <Card 
                  key={index} 
                  className={`bg-gradient-to-br ${getColorClasses(feature.color)} border-2 hover:shadow-lg transition-all duration-300 hover:scale-105`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="flex-shrink-0">
                        <feature.icon className="h-8 w-8 text-current" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                        <p className="text-gray-700 text-sm leading-relaxed">{feature.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Additional Features */}
            <div className="bg-gray-50 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-center mb-8 text-gray-900">
                More Features That Make a Difference
              </h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {additionalFeatures.map((feature, index) => (
                  <div key={index} className="bg-white rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-center space-x-3 mb-2">
                      <feature.icon className="h-5 w-5 text-blue-500" />
                      <h4 className="font-semibold text-gray-900">{feature.title}</h4>
                    </div>
                    <p className="text-gray-600 text-sm">{feature.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Feature Highlight */}
            <div className="mt-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl p-8 text-white">
              <div className="text-center">
                <h3 className="text-2xl font-bold mb-4">Why SkillBridge Works</h3>
                <p className="text-lg mb-6 opacity-90">
                  Built by developers who understand rural challenges, tested in real communities, 
                  and designed with feedback from actual users across India.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
                  <div>
                    <div className="text-3xl font-bold">50+</div>
                    <div className="text-sm opacity-80">Villages Tested</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold">4</div>
                    <div className="text-sm opacity-80">Native Languages</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold">95%</div>
                    <div className="text-sm opacity-80">Completion Rate</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default Features;